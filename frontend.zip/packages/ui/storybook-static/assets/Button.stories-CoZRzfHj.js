import{B as s}from"./Button-DMk9Du2v.js";import"./iframe-D66kx2sK.js";import"./preload-helper-D1UD9lgW.js";import"./cn-DaT-yT0k.js";import"./createLucideIcon-D1gYIQvt.js";const p={title:"Primitives/Button",component:s,args:{children:"Save"},argTypes:{variant:{control:"select",options:["primary","secondary","teal","danger","ghost","outline"]},size:{control:"select",options:["sm","md","lg","icon"]},loading:{control:"boolean"},disabled:{control:"boolean"}}},r={args:{variant:"primary"}},a={args:{variant:"secondary"}},e={args:{variant:"danger",children:"Delete"}},n={args:{variant:"primary",loading:!0,children:"Saving"}},o={args:{variant:"primary",disabled:!0}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  args: {
    variant: "primary"
  }
}`,...r.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  args: {
    variant: "secondary"
  }
}`,...a.parameters?.docs?.source}}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  args: {
    variant: "danger",
    children: "Delete"
  }
}`,...e.parameters?.docs?.source}}};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  args: {
    variant: "primary",
    loading: true,
    children: "Saving"
  }
}`,...n.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    variant: "primary",
    disabled: true
  }
}`,...o.parameters?.docs?.source}}};const l=["Primary","Secondary","Danger","Loading","Disabled"];export{e as Danger,o as Disabled,n as Loading,r as Primary,a as Secondary,l as __namedExportsOrder,p as default};
