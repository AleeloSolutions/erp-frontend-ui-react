import{D as o}from"./Dropdown-dM6okEyI.js";import"./iframe-D66kx2sK.js";import"./preload-helper-D1UD9lgW.js";import"./cn-DaT-yT0k.js";import"./Button-DMk9Du2v.js";import"./createLucideIcon-D1gYIQvt.js";const c={title:"Composites/Dropdown",component:o,args:{label:"Actions",items:[{key:"edit",label:"Edit",onClick:()=>{}},{key:"duplicate",label:"Duplicate",onClick:()=>{}},{key:"delete",label:"Delete",danger:!0,onClick:()=>{}}]}},e={},r={args:{align:"right"}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:"{}",...e.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  args: {
    align: "right"
  }
}`,...r.parameters?.docs?.source}}};const p=["Default","AlignRight"];export{r as AlignRight,e as Default,p as __namedExportsOrder,c as default};
