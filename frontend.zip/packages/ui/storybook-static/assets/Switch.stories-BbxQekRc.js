import{r as p,j as e}from"./iframe-D66kx2sK.js";import{c as t}from"./cn-DaT-yT0k.js";import"./preload-helper-D1UD9lgW.js";const n=p.forwardRef(({className:l,label:o,id:c,...i},d)=>e.jsxs("label",{htmlFor:c,className:t("inline-flex cursor-pointer items-center gap-2 text-[11px] text-erp-text",i.disabled&&"cursor-not-allowed opacity-60",l),children:[e.jsxs("span",{className:"relative inline-flex h-[18px] w-[32px] items-center",children:[e.jsx("input",{ref:d,id:c,type:"checkbox",role:"switch",className:"peer sr-only",...i}),e.jsx("span",{"aria-hidden":!0,className:t("absolute inset-0 rounded-full border border-[#C8D2DE] bg-[#EEF1F4] transition-colors","peer-checked:border-erp-blue peer-checked:bg-erp-blue","peer-focus-visible:ring-2 peer-focus-visible:ring-[rgba(46,95,167,0.16)]","peer-disabled:opacity-60")}),e.jsx("span",{"aria-hidden":!0,className:t("absolute left-[2px] h-[12px] w-[12px] rounded-full bg-white shadow-sm transition-transform","peer-checked:translate-x-[14px]")})]}),o?e.jsx("span",{children:o}):null]}));n.displayName="Switch";const h={title:"Primitives/Switch",component:n,args:{id:"demo-switch",label:"Email notifications"}},r={},s={args:{defaultChecked:!0}},a={args:{disabled:!0,defaultChecked:!0}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:"{}",...r.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  args: {
    defaultChecked: true
  }
}`,...s.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true,
    defaultChecked: true
  }
}`,...a.parameters?.docs?.source}}};const b=["Default","On","Disabled"];export{r as Default,a as Disabled,s as On,b as __namedExportsOrder,h as default};
