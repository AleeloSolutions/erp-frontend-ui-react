import{S as s}from"./Select-BxUzfzwO.js";import"./iframe-D66kx2sK.js";import"./preload-helper-D1UD9lgW.js";import"./cn-DaT-yT0k.js";const o=[{label:"Active",value:"active"},{label:"Inactive",value:"inactive"},{label:"Pending",value:"pending",disabled:!0}],u={title:"Primitives/Select",component:s,args:{options:o,placeholder:"Select status"}},e={},r={args:{defaultValue:"active"}},a={args:{error:!0}},t={args:{disabled:!0,defaultValue:"active"}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:"{}",...e.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  args: {
    defaultValue: "active"
  }
}`,...r.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  args: {
    error: true
  }
}`,...a.parameters?.docs?.source}}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true,
    defaultValue: "active"
  }
}`,...t.parameters?.docs?.source}}};const d=["Default","WithValue","WithError","Disabled"];export{e as Default,t as Disabled,a as WithError,r as WithValue,d as __namedExportsOrder,u as default};
