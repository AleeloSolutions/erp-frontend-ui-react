import{j as e,r as h}from"./iframe-D66kx2sK.js";import{c as i}from"./cn-DaT-yT0k.js";import{B as F}from"./Button-DMk9Du2v.js";import{I as w}from"./Input-t8hGEEaU.js";import{S as y}from"./Select-BxUzfzwO.js";import{T as C}from"./Textarea-BgyTWq0R.js";import"./preload-helper-D1UD9lgW.js";import"./createLucideIcon-D1gYIQvt.js";function E({onCancel:r,cancelLabel:t="Cancel",secondaryLabel:n="Save draft",onSecondary:a,submitLabel:l="Submit",submitting:s=!1,disabled:o=!1,left:m,right:u,className:b,customOnly:c=!1}){return e.jsxs("div",{className:i("flex min-h-11 flex-wrap items-center gap-1.5 border-t border-erp-border bg-erp-surface-alt px-2.5 py-1.5",b),children:[m,!c&&r?e.jsx(F,{type:"button",variant:"secondary",onClick:r,disabled:s,children:t}):null,e.jsxs("div",{className:"ml-auto flex flex-wrap items-center gap-1.5",children:[u,c?null:e.jsxs(e.Fragment,{children:[a?e.jsx(F,{type:"button",variant:"secondary",onClick:a,disabled:s||o,children:n}):null,e.jsx(F,{type:"submit",variant:"teal",loading:s,disabled:o,children:l})]})]})]})}function f({title:r,description:t,stepper:n,summary:a,actions:l,actionProps:s,serverError:o,children:m,className:u,onSubmit:b,id:c}){return e.jsxs("form",{id:c,onSubmit:b,className:i("overflow-hidden rounded-lg border border-erp-border bg-white",u),noValidate:!0,children:[e.jsxs("div",{className:"flex min-h-11 flex-wrap items-center gap-2 border-b border-erp-border bg-erp-surface-alt px-3",children:[e.jsxs("div",{className:"min-w-0 py-2",children:[e.jsx("h2",{className:"m-0 text-[15px] font-bold text-erp-text",children:r}),t?e.jsx("span",{className:"text-[11px] text-erp-subtle",children:t}):null]}),n]}),o?e.jsx("div",{className:"border-b border-erp-error/20 bg-erp-error-bg px-3 py-2 text-[11px] text-erp-error",role:"alert",children:o}):null,e.jsxs("div",{className:i("grid grid-cols-1",a&&"min-[981px]:grid-cols-[minmax(0,1fr)_280px]"),children:[e.jsx("div",{className:"min-w-0",children:m}),a]}),l??(s?e.jsx(E,{...s}):null)]})}function v({title:r,description:t,className:n,children:a,...l}){return e.jsxs("section",{className:i("border-b border-erp-border p-[13px]",n),...l,children:[e.jsx("h3",{className:"mb-2.5 mt-0 text-[11px] font-bold text-[#4E5D6C]",children:r}),t?e.jsx("p",{className:"mb-2.5 mt-[-6px] text-[10.5px] text-erp-subtle",children:t}):null,a]})}function N({columns:r=12,className:t,children:n,...a}){return e.jsx("div",{className:i("grid grid-cols-1 gap-x-3 gap-y-2.5",r===12&&"min-[721px]:grid-cols-12",t),...a,children:n})}const I={3:"min-[721px]:col-span-3",4:"min-[721px]:col-span-4",5:"min-[721px]:col-span-5",6:"min-[721px]:col-span-6",7:"min-[721px]:col-span-7",8:"min-[721px]:col-span-8",9:"min-[721px]:col-span-9",10:"min-[721px]:col-span-10",12:"min-[721px]:col-span-12"};function x({label:r,htmlFor:t,description:n,required:a,error:l,span:s=6,className:o,children:m}){return e.jsxs("div",{className:i("col-span-12 flex flex-col gap-1",I[s]??"min-[721px]:col-span-6",o),children:[r?e.jsxs("label",{htmlFor:t,className:"text-[10.5px] font-semibold text-[#4B5563]",children:[r,a?e.jsx("span",{className:"ml-0.5 text-erp-error","aria-hidden":!0,children:"*"}):null]}):null,m,n&&!l?e.jsx("p",{className:"m-0 text-[10px] text-erp-subtle",children:n}):null,l?e.jsx("p",{className:"m-0 text-[10px] text-erp-error",role:"alert",children:l}):null]})}const j=h.forwardRef(function(t,n){return e.jsx(w,{ref:n,...t})});j.displayName="FormInput";const S=h.forwardRef(function(t,n){return e.jsx(y,{ref:n,...t})});S.displayName="FormSelect";const g=h.forwardRef(function(t,n){return e.jsx(C,{ref:n,...t})});g.displayName="FormTextarea";const B={title:"Composites/Form",component:f},d={render:()=>e.jsx(f,{title:"New customer",description:"Capture basic account details.",actionProps:{onCancel:()=>{},submitLabel:"Create"},onSubmit:r=>r.preventDefault(),children:e.jsx(v,{title:"Profile",children:e.jsxs(N,{children:[e.jsx(x,{label:"Name",htmlFor:"name",required:!0,children:e.jsx(j,{id:"name",name:"name",placeholder:"Acme Trading"})}),e.jsx(x,{label:"Status",htmlFor:"status",children:e.jsx(S,{id:"status",name:"status",options:[{label:"Active",value:"active"},{label:"Inactive",value:"inactive"}]})}),e.jsx(x,{label:"Notes",htmlFor:"notes",span:12,children:e.jsx(g,{id:"notes",name:"notes",rows:3})})]})})})},p={render:()=>e.jsx(f,{title:"New customer",serverError:"Email is already registered.",actionProps:{submitLabel:"Retry"},onSubmit:r=>r.preventDefault(),children:e.jsx(v,{title:"Profile",children:e.jsx(N,{children:e.jsx(x,{label:"Email",htmlFor:"email",error:"Must be unique",required:!0,children:e.jsx(j,{id:"email",name:"email",type:"email",error:!0})})})})})};d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: () => <FormShell title="New customer" description="Capture basic account details." actionProps={{
    onCancel: () => undefined,
    submitLabel: "Create"
  }} onSubmit={event => event.preventDefault()}>\r
      <FormSection title="Profile">\r
        <FormGrid>\r
          <FormField label="Name" htmlFor="name" required>\r
            <FormInput id="name" name="name" placeholder="Acme Trading" />\r
          </FormField>\r
          <FormField label="Status" htmlFor="status">\r
            <FormSelect id="status" name="status" options={[{
            label: "Active",
            value: "active"
          }, {
            label: "Inactive",
            value: "inactive"
          }]} />\r
          </FormField>\r
          <FormField label="Notes" htmlFor="notes" span={12}>\r
            <FormTextarea id="notes" name="notes" rows={3} />\r
          </FormField>\r
        </FormGrid>\r
      </FormSection>\r
    </FormShell>
}`,...d.parameters?.docs?.source}}};p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: () => <FormShell title="New customer" serverError="Email is already registered." actionProps={{
    submitLabel: "Retry"
  }} onSubmit={event => event.preventDefault()}>\r
      <FormSection title="Profile">\r
        <FormGrid>\r
          <FormField label="Email" htmlFor="email" error="Must be unique" required>\r
            <FormInput id="email" name="email" type="email" error />\r
          </FormField>\r
        </FormGrid>\r
      </FormSection>\r
    </FormShell>
}`,...p.parameters?.docs?.source}}};const _=["CreateCustomer","WithServerError"];export{d as CreateCustomer,p as WithServerError,_ as __namedExportsOrder,B as default};
