import{j as r}from"./iframe-D66kx2sK.js";import{M as o}from"./MobileNav-CD-zafEq.js";import{d as a,R as t}from"./demo-nav-2lJBi6kQ.js";import"./preload-helper-D1UD9lgW.js";import"./cn-DaT-yT0k.js";import"./createLucideIcon-D1gYIQvt.js";const p={title:"Layout/MobileNav",component:o,decorators:[s=>r.jsx(t,{children:r.jsx("div",{className:"relative h-[120px] max-w-sm overflow-hidden rounded-lg border border-erp-border bg-erp-bg",children:r.jsx(s,{})})})],args:{items:a,activeKey:"sales"}},e={args:{items:a,activeKey:"sales",className:"!relative !inset-auto !flex h-14 w-full"}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  args: {
    items: demoMobileNav,
    activeKey: "sales",
    className: "!relative !inset-auto !flex h-14 w-full"
  }
}`,...e.parameters?.docs?.source}}};const u=["Default"];export{e as Default,u as __namedExportsOrder,p as default};
