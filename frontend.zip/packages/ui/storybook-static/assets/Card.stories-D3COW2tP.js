import{j as r}from"./iframe-D66kx2sK.js";import{c as n}from"./cn-DaT-yT0k.js";import{B as o}from"./Button-DMk9Du2v.js";import"./preload-helper-D1UD9lgW.js";import"./createLucideIcon-D1gYIQvt.js";function d({className:e,children:t,...a}){return r.jsx("div",{className:n("overflow-hidden rounded-lg border border-erp-border bg-white",e),...a,children:t})}function i({className:e,children:t,...a}){return r.jsx("div",{className:n("flex items-center gap-2 border-b border-erp-border bg-erp-surface-alt px-3 py-2.5",e),...a,children:t})}function m({className:e,children:t,...a}){return r.jsx("h3",{className:n("m-0 text-[13px] font-bold text-erp-text",e),...a,children:t})}function c({className:e,children:t,...a}){return r.jsx("div",{className:n("p-3",e),...a,children:t})}function p({className:e,children:t,...a}){return r.jsx("div",{className:n("flex items-center gap-2 border-t border-erp-border bg-erp-surface-alt px-3 py-2",e),...a,children:t})}const b={title:"Primitives/Card",component:d},s={render:()=>r.jsxs(d,{className:"max-w-md",children:[r.jsx(i,{children:r.jsx(m,{children:"Customer summary"})}),r.jsx(c,{children:r.jsx("p",{className:"m-0 text-[12px] text-erp-muted",children:"Open balance, last invoice, and recent activity."})}),r.jsx(p,{children:r.jsx(o,{variant:"primary",size:"sm",children:"View"})})]})};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: () => <Card className="max-w-md">\r
      <CardHeader>\r
        <CardTitle>Customer summary</CardTitle>\r
      </CardHeader>\r
      <CardContent>\r
        <p className="m-0 text-[12px] text-erp-muted">\r
          Open balance, last invoice, and recent activity.\r
        </p>\r
      </CardContent>\r
      <CardFooter>\r
        <Button variant="primary" size="sm">\r
          View\r
        </Button>\r
      </CardFooter>\r
    </Card>
}`,...s.parameters?.docs?.source}}};const j=["Default"];export{s as Default,j as __namedExportsOrder,b as default};
