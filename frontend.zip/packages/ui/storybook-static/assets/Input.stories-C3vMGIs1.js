import{I as t}from"./Input-t8hGEEaU.js";import"./iframe-D66kx2sK.js";import"./preload-helper-D1UD9lgW.js";import"./cn-DaT-yT0k.js";const d={title:"Primitives/Input",component:t,args:{placeholder:"Enter value"}},e={},r={args:{defaultValue:"Acme Trading LLC"}},a={args:{error:!0,defaultValue:"invalid@"}},s={args:{disabled:!0,defaultValue:"Read only"}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:"{}",...e.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  args: {
    defaultValue: "Acme Trading LLC"
  }
}`,...r.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  args: {
    error: true,
    defaultValue: "invalid@"
  }
}`,...a.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true,
    defaultValue: "Read only"
  }
}`,...s.parameters?.docs?.source}}};const l=["Default","WithValue","WithError","Disabled"];export{e as Default,s as Disabled,a as WithError,r as WithValue,l as __namedExportsOrder,d as default};
