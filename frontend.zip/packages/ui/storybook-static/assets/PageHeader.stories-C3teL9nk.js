import{j as e}from"./iframe-D66kx2sK.js";import{P as t}from"./PageHeader-CTsKyoEx.js";import{B as a}from"./Button-DMk9Du2v.js";import{b as m,U as n,R as u}from"./demo-nav-2lJBi6kQ.js";import"./preload-helper-D1UD9lgW.js";import"./Select-BxUzfzwO.js";import"./cn-DaT-yT0k.js";import"./PageSubmenu-C8gxlmk4.js";import"./createLucideIcon-D1gYIQvt.js";const f={title:"Layout/PageHeader",component:t,decorators:[o=>e.jsx(u,{children:e.jsx(o,{})})],args:{module:"Sales",section:"Customers",title:"Customers",description:"Manage customer accounts.",icon:e.jsx(n,{className:"h-4 w-4","aria-hidden":!0}),actions:e.jsx(a,{variant:"primary",children:"Create"})}},r={},s={args:{submenu:{module:"Sales",items:m,activeKey:"customers"}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:"{}",...r.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  args: {
    submenu: {
      module: "Sales",
      items: demoSubmenu,
      activeKey: "customers"
    }
  }
}`,...s.parameters?.docs?.source}}};const h=["Default","WithSubmenu"];export{r as Default,s as WithSubmenu,h as __namedExportsOrder,f as default};
