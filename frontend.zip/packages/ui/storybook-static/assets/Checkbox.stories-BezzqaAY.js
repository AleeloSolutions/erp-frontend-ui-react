import{C as t}from"./Checkbox-CBGsNXQc.js";import"./iframe-D66kx2sK.js";import"./preload-helper-D1UD9lgW.js";import"./cn-DaT-yT0k.js";const m={title:"Primitives/Checkbox",component:t,args:{label:"Include inactive",id:"demo-checkbox"}},e={},r={args:{defaultChecked:!0}},a={args:{indeterminate:!0}},s={args:{disabled:!0,defaultChecked:!0}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:"{}",...e.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  args: {
    defaultChecked: true
  }
}`,...r.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  args: {
    indeterminate: true
  }
}`,...a.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true,
    defaultChecked: true
  }
}`,...s.parameters?.docs?.source}}};const i=["Default","Checked","Indeterminate","Disabled"];export{r as Checked,e as Default,s as Disabled,a as Indeterminate,i as __namedExportsOrder,m as default};
