import{r as i,j as o}from"./iframe-D66kx2sK.js";import{c}from"./cn-DaT-yT0k.js";import{B as d}from"./Button-DMk9Du2v.js";import"./preload-helper-D1UD9lgW.js";import"./createLucideIcon-D1gYIQvt.js";function n({content:p,children:m,side:l="top",className:u,...x}){const[s,e]=i.useState(!1),a=i.useId();return o.jsxs("div",{className:c("relative inline-flex",u),onMouseEnter:()=>e(!0),onMouseLeave:()=>e(!1),onFocus:()=>e(!0),onBlur:()=>e(!1),...x,children:[o.jsx("div",{"aria-describedby":s?a:void 0,children:m}),s?o.jsx("div",{id:a,role:"tooltip",className:c("pointer-events-none absolute left-1/2 z-50 -translate-x-1/2 whitespace-nowrap rounded-md bg-nav px-2 py-1 text-[10px] font-semibold text-white shadow-md",l==="top"?"bottom-[calc(100%+6px)]":"top-[calc(100%+6px)]"),children:p}):null]})}const B={title:"Primitives/Tooltip",component:n},t={render:()=>o.jsx(n,{content:"More information",side:"top",children:o.jsx(d,{variant:"secondary",children:"Hover me"})})},r={render:()=>o.jsx(n,{content:"More information",side:"bottom",children:o.jsx(d,{variant:"secondary",children:"Hover me"})})};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  render: () => <Tooltip content="More information" side="top">\r
      <Button variant="secondary">Hover me</Button>\r
    </Tooltip>
}`,...t.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  render: () => <Tooltip content="More information" side="bottom">\r
      <Button variant="secondary">Hover me</Button>\r
    </Tooltip>
}`,...r.parameters?.docs?.source}}};const T=["Top","Bottom"];export{r as Bottom,t as Top,T as __namedExportsOrder,B as default};
