import"./iframe-D66kx2sK.js";import"./Checkbox-CBGsNXQc.js";import"./Button-DMk9Du2v.js";import"./Input-t8hGEEaU.js";import"./Select-BxUzfzwO.js";import{D as t}from"./DataTableFilters-BRkBMYyc.js";import"./preload-helper-D1UD9lgW.js";import"./cn-DaT-yT0k.js";import"./createLucideIcon-D1gYIQvt.js";import"./x-Dn5ZJQDw.js";const d={title:"Composites/FilterBar",component:t},e={args:{resultCount:24,chips:[{key:"search",label:"Search",value:"acme",onRemove:()=>{}},{key:"status",label:"Status",value:"Active",onRemove:()=>{}}],onClearAll:()=>{}}},r={args:{resultCount:0,chips:[]}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  args: {
    resultCount: 24,
    chips: [{
      key: "search",
      label: "Search",
      value: "acme",
      onRemove: () => undefined
    }, {
      key: "status",
      label: "Status",
      value: "Active",
      onRemove: () => undefined
    }],
    onClearAll: () => undefined
  }
}`,...e.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  args: {
    resultCount: 0,
    chips: []
  }
}`,...r.parameters?.docs?.source}}};const v=["WithChips","Empty"];export{r as Empty,e as WithChips,v as __namedExportsOrder,d as default};
