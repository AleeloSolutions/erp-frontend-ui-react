import{j as t}from"./iframe-D66kx2sK.js";import{S as o}from"./StatusBadge-kMVeydeX.js";import"./preload-helper-D1UD9lgW.js";import"./cn-DaT-yT0k.js";const d={title:"Primitives/StatusBadge",component:o,args:{status:"active"}},a={},e={render:()=>t.jsx("div",{className:"flex flex-wrap gap-2",children:["paid","pending","approved","overdue","draft","partial","active","inactive","open","closed"].map(r=>t.jsx(o,{status:r},r))})},s={args:{status:"pending",label:"Awaiting approval"}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:"{}",...a.parameters?.docs?.source}}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  render: () => <div className="flex flex-wrap gap-2">\r
      {(["paid", "pending", "approved", "overdue", "draft", "partial", "active", "inactive", "open", "closed"] as const).map(status => <StatusBadge key={status} status={status} />)}\r
    </div>
}`,...e.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  args: {
    status: "pending",
    label: "Awaiting approval"
  }
}`,...s.parameters?.docs?.source}}};const l=["Default","AllStatuses","CustomLabel"];export{e as AllStatuses,s as CustomLabel,a as Default,l as __namedExportsOrder,d as default};
