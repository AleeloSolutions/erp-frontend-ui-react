import{T as o}from"./Textarea-BgyTWq0R.js";import"./iframe-D66kx2sK.js";import"./preload-helper-D1UD9lgW.js";import"./cn-DaT-yT0k.js";const d={title:"Primitives/Textarea",component:o,args:{placeholder:"Add notes…",rows:4}},e={},r={args:{defaultValue:"Customer prefers email follow-up."}},a={args:{error:!0,defaultValue:"Too short"}},s={args:{disabled:!0,defaultValue:"Locked"}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:"{}",...e.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  args: {
    defaultValue: "Customer prefers email follow-up."
  }
}`,...r.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  args: {
    error: true,
    defaultValue: "Too short"
  }
}`,...a.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true,
    defaultValue: "Locked"
  }
}`,...s.parameters?.docs?.source}}};const m=["Default","WithValue","WithError","Disabled"];export{e as Default,s as Disabled,a as WithError,r as WithValue,m as __namedExportsOrder,d as default};
