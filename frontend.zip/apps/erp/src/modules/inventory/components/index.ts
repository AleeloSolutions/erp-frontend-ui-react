/** Inventory module components. */
export {};
